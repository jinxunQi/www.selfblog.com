INSERT INTO `bl_cate` VALUES (1, '美食');
INSERT INTO `bl_cate` VALUES (2, '服装');
INSERT INTO `bl_cate` VALUES (3, '体育');
INSERT INTO `bl_cate` VALUES (4, '新闻');
INSERT INTO `bl_cate` VALUES (5, '旅游');
INSERT INTO `bl_cate` VALUES (6, '科学');
