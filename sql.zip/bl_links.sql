INSERT INTO `bl_links` VALUES (1, '百度', 'http://www.baidu.com', '');
INSERT INTO `bl_links` VALUES (2, '360', 'http://www.360.com', '这是360官网');
INSERT INTO `bl_links` VALUES (3, '腾讯网', 'http://www.qq.com', '腾讯官网');
INSERT INTO `bl_links` VALUES (4, '新浪网', 'http://www.sina.com.cn', '');
INSERT INTO `bl_links` VALUES (5, 'youtube', 'http://www.youtube.com', '');
INSERT INTO `bl_links` VALUES (6, '博客园', 'https://www.cnblogs.com/', '博客园');
