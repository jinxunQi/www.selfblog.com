INSERT INTO `bl_tags` VALUES (1, '奇趣');
INSERT INTO `bl_tags` VALUES (2, '八卦');
INSERT INTO `bl_tags` VALUES (3, '星座');
INSERT INTO `bl_tags` VALUES (4, '测试');
