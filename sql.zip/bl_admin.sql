INSERT INTO `bl_admin` VALUES (1, 'admin', '1bb75fae5c0f9e8b520351c855003f05');
INSERT INTO `bl_admin` VALUES (2, 'zhansan', '1bb75fae5c0f9e8b520351c855003f05');
INSERT INTO `bl_admin` VALUES (3, 'lisi', '1bb75fae5c0f9e8b520351c855003f05');
INSERT INTO `bl_admin` VALUES (4, 'wangwu', '1bb75fae5c0f9e8b520351c855003f05');
INSERT INTO `bl_admin` VALUES (5, 'dabai', '1bb75fae5c0f9e8b520351c855003f05');
INSERT INTO `bl_admin` VALUES (6, 'xiaobai', '1bb75fae5c0f9e8b520351c855003f05');
INSERT INTO `bl_admin` VALUES (7, 'xiaoming', '1bb75fae5c0f9e8b520351c855003f05');
